# Uno Read data File
- this is function for read datafile 

# Example Code

 import readDataFile
 
### readDataFile.ReadDataFile(파일명)
 - 단일 파일 또는 여러 파일명 / 탐색기 없이 파일 불러오기
### readDataFile.ReadDataFile(폴더명)  
 - 해당 폴더에 탐색기 실행
### readDataFile.ReadDataFile()
 - 기본 폴더에 탐색기 실행